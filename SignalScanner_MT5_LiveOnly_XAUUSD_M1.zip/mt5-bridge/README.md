# LIVE-ONLY MT5 bridge

Runs on the same Windows PC/VPS as the logged-in MT5 desktop terminal. This bridge accepts only live mode; it will not simulate trades or run on an MT5 demo account.

Install Python 3.11 64-bit, MT5 desktop, and log into the intended real account. Then:
1. `py -m venv .venv`
2. `.\.venv\Scripts\Activate.ps1`
3. `pip install -r requirements.txt`
4. Set a strong private key: `$env:MT5_BRIDGE_API_KEY = "replace-with-a-long-random-secret"`
5. Keep live disabled until you are ready: `$env:ALLOW_LIVE_TRADING = "false"`
6. Run locally for setup: `uvicorn bridge:app --host 127.0.0.1 --port 8443`

Only after independent testing and explicit decision to trade live, set `ALLOW_LIVE_TRADING=true`. App confirmation is also required. Put access behind a private VPN and HTTPS reverse proxy; never expose this service directly to the internet or send the API key over plain HTTP.

Strategy: EMA9/EMA21 crossover plus RSI14 confirmation on closed M1 candles; SL 1.5x ATR14; TP 2R; risk-based volume with 0.10-lot cap; max one open trade; daily equity-loss stop 2%. Check broker symbol suffix and contract tick values. Emergency stop halts new entries but does not close existing positions. No profitability is guaranteed.
