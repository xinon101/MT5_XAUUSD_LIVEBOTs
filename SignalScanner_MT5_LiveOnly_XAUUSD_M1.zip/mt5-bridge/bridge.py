"""
MT5 automatic XAUUSD strategy bridge (Windows only).
Runs on the same Windows PC/VPS as the logged-in MetaTrader 5 desktop terminal.
Keep behind a private VPN or HTTPS reverse proxy; never expose this service directly.
"""
import os, time, threading, secrets, math
from datetime import datetime, timezone, date
from typing import Literal

import MetaTrader5 as mt5
import pandas as pd
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel, Field

API_KEY = os.environ.get("MT5_BRIDGE_API_KEY", "")
ALLOW_LIVE = os.environ.get("ALLOW_LIVE_TRADING", "false").lower() == "true"
app = FastAPI(title="Private MT5 Auto-Trading Bridge", docs_url=None, redoc_url=None)
lock = threading.RLock()
state = {
    "running": False, "mode": "live", "symbol": "XAUUSD", "timeframe": "M1",
    "fast_ema": 9, "slow_ema": 21, "rsi_period": 14, "rsi_buy": 55.0,
    "rsi_sell": 45.0, "risk_percent": 0.5, "sl_atr_multiple": 1.5,
    "tp_r_multiple": 2.0, "max_open_trades": 1, "daily_loss_limit_percent": 2.0,
    "last_signal": "Bot stopped", "last_bar": 0, "last_error": "",
    "emergency_stop": False, "trades_today": 0, "day_start_equity": None,
    "day_key": "", "last_order": None
}
worker_thread = None

def authorize(authorization: str | None):
    if not API_KEY:
        raise HTTPException(503, "Bridge API key is not configured")
    if not authorization or not secrets.compare_digest(authorization, f"Bearer {API_KEY}"):
        raise HTTPException(401, "Unauthorized")

def ensure_mt5():
    if not mt5.initialize():
        raise HTTPException(503, f"MT5 initialize failed: {mt5.last_error()}")
    info = mt5.account_info()
    if info is None:
        raise HTTPException(503, "No MT5 account logged into the terminal")
    return info

def timeframe_value():
    return mt5.TIMEFRAME_M1

def indicators(symbol):
    rates = mt5.copy_rates_from_pos(symbol, timeframe_value(), 0, 150)
    if rates is None or len(rates) < 60:
        raise RuntimeError(f"Not enough M1 candles for {symbol}: {mt5.last_error()}")
    df = pd.DataFrame(rates)
    close = df["close"]
    fast = close.ewm(span=state["fast_ema"], adjust=False).mean()
    slow = close.ewm(span=state["slow_ema"], adjust=False).mean()
    delta = close.diff()
    gain = delta.clip(lower=0).ewm(alpha=1/state["rsi_period"], adjust=False).mean()
    loss = (-delta.clip(upper=0)).ewm(alpha=1/state["rsi_period"], adjust=False).mean()
    rs = gain / loss.replace(0, float("nan"))
    rsi = 100 - (100 / (1 + rs))
    # Use the last fully closed candle and its predecessor to avoid acting on a forming candle.
    i = len(df) - 2
    prev = i - 1
    side = None
    if fast.iloc[prev] <= slow.iloc[prev] and fast.iloc[i] > slow.iloc[i] and rsi.iloc[i] >= state["rsi_buy"]:
        side = "buy"
    elif fast.iloc[prev] >= slow.iloc[prev] and fast.iloc[i] < slow.iloc[i] and rsi.iloc[i] <= state["rsi_sell"]:
        side = "sell"
    return int(df["time"].iloc[i]), side, float(df["close"].iloc[i]), float(rsi.iloc[i]), float(fast.iloc[i]), float(slow.iloc[i])

def open_positions(symbol):
    positions = mt5.positions_get(symbol=symbol)
    return list(positions) if positions else []

def today_key():
    return datetime.now().strftime("%Y-%m-%d")

def ensure_day_baseline(info):
    key = today_key()
    if state["day_key"] != key:
        state["day_key"] = key
        state["day_start_equity"] = float(info.equity)
        state["trades_today"] = 0

def size_volume(symbol, entry, sl, risk_money):
    spec = mt5.symbol_info(symbol)
    if spec is None:
        raise RuntimeError("MT5 symbol specification unavailable")
    distance = abs(entry - sl)
    tick_size = spec.trade_tick_size or spec.point
    tick_value = spec.trade_tick_value_loss or spec.trade_tick_value
    if not tick_size or not tick_value or distance <= 0:
        raise RuntimeError("Cannot calculate risk-based lot size from symbol tick values")
    loss_per_lot = distance / tick_size * tick_value
    raw = risk_money / loss_per_lot
    step = spec.volume_step or 0.01
    vol = math.floor(raw / step) * step
    vol = min(vol, spec.volume_max, 0.10)  # conservative hard cap
    if vol < spec.volume_min:
        raise RuntimeError(f"Risk-based volume {vol} is below broker minimum {spec.volume_min}; trade skipped")
    return round(vol, 8)

def submit_strategy_order(symbol, side, atr):
    info = mt5.account_info()
    if info is None:
        raise RuntimeError("MT5 account information unavailable")
    if state["mode"] == "live":
        if not ALLOW_LIVE:
            raise RuntimeError("Live trading is disabled on bridge environment")
        if info.trade_mode == mt5.ACCOUNT_TRADE_MODE_DEMO:
            raise RuntimeError("Bridge is in LIVE mode but MT5 account is a DEMO account; mode mismatch")
    if not info.trade_allowed:
        raise RuntimeError("Trading is not allowed by MT5 account/terminal")
    ensure_day_baseline(info)
    baseline = float(state["day_start_equity"] or info.equity)
    daily_loss_pct = max(0.0, (baseline - float(info.equity)) / max(baseline, 1.0) * 100)
    if daily_loss_pct >= state["daily_loss_limit_percent"]:
        state["running"] = False
        state["emergency_stop"] = True
        raise RuntimeError(f"Daily loss limit reached ({daily_loss_pct:.2f}%). Bot stopped.")
    if len(open_positions(symbol)) >= state["max_open_trades"]:
        raise RuntimeError("Maximum open trades reached; signal skipped")
    tick = mt5.symbol_info_tick(symbol)
    spec = mt5.symbol_info(symbol)
    if tick is None or spec is None:
        raise RuntimeError("No current quote/specification")
    price = tick.ask if side == "buy" else tick.bid
    stop_distance = max(atr * state["sl_atr_multiple"], spec.point * 20)
    sl = price - stop_distance if side == "buy" else price + stop_distance
    tp_distance = stop_distance * state["tp_r_multiple"]
    tp = price + tp_distance if side == "buy" else price - tp_distance
    risk_money = float(info.equity) * state["risk_percent"] / 100.0
    volume = size_volume(symbol, price, sl, risk_money)
    if not mt5.symbol_select(symbol, True):
        raise RuntimeError(f"MT5 symbol unavailable: {symbol}")
    request = {
        "action": mt5.TRADE_ACTION_DEAL, "symbol": symbol, "volume": volume,
        "type": mt5.ORDER_TYPE_BUY if side == "buy" else mt5.ORDER_TYPE_SELL,
        "price": price, "sl": round(sl, spec.digits), "tp": round(tp, spec.digits),
        "deviation": 20, "magic": 2601001, "comment": "SignalScanner EMA-RSI M1",
        "type_time": mt5.ORDER_TIME_GTC, "type_filling": spec.filling_mode
    }
    result = mt5.order_send(request)
    if result is None:
        raise RuntimeError(f"order_send failed: {mt5.last_error()}")
    if result.retcode != mt5.TRADE_RETCODE_DONE:
        raise RuntimeError(f"MT5 rejected order: retcode={result.retcode}, comment={result.comment}")
    state["trades_today"] += 1
    state["last_order"] = {"order": result.order, "deal": result.deal, "side": side,
                           "volume": result.volume, "price": result.price, "sl": request["sl"], "tp": request["tp"]}
    return state["last_order"]

def worker():
    while True:
        with lock:
            if not state["running"]:
                break
            if state["emergency_stop"]:
                state["running"] = False
                break
        try:
            info = ensure_mt5()
            with lock:
                ensure_day_baseline(info)
                symbol = state["symbol"]
                if state["mode"] == "live" and not ALLOW_LIVE:
                    raise RuntimeError("Live trading disabled by server configuration")
            if not mt5.symbol_select(symbol, True):
                raise RuntimeError(f"Symbol not available: {symbol}. Check broker suffix.")
            bar_time, side, close, rsi, fast, slow = indicators(symbol)
            with lock:
                if bar_time != state["last_bar"]:
                    state["last_bar"] = bar_time
                    state["last_signal"] = f"Closed M1 candle {bar_time}: close={close:.3f}, EMA{state['fast_ema']}={fast:.3f}, EMA{state['slow_ema']}={slow:.3f}, RSI={rsi:.1f}, signal={side or 'none'}"
                    if side:
                        rates = mt5.copy_rates_from_pos(symbol, timeframe_value(), 1, 30)
                        df = pd.DataFrame(rates)
                        tr = (df["high"] - df["low"]).abs()
                        atr = float(tr.rolling(14).mean().iloc[-1])
                        submit_strategy_order(symbol, side, atr)
                        state["last_signal"] += f" | order sent: {side.upper()}"
                state["last_error"] = ""
        except Exception as exc:
            with lock:
                state["last_error"] = str(exc)
                state["last_signal"] = f"Bot warning: {exc}"
        time.sleep(3)

class StartRequest(BaseModel):
    mode: Literal["live"]
    symbol: str = Field(default="XAUUSD", min_length=1, max_length=32)
    risk_percent: float = Field(default=0.5, ge=0.1, le=1.0)
    sl_atr_multiple: float = Field(default=1.5, ge=0.5, le=5.0)
    tp_r_multiple: float = Field(default=2.0, ge=1.0, le=5.0)
    max_open_trades: int = Field(default=1, ge=1, le=3)
    daily_loss_limit_percent: float = Field(default=2.0, ge=0.5, le=5.0)
    live_confirmed: bool = False

@app.get("/health")
def health(authorization: str | None = Header(default=None)):
    authorize(authorization); info = ensure_mt5()
    return {"ok": True, "terminal_connected": True, "account_login": info.login}

@app.get("/account")
def account(authorization: str | None = Header(default=None)):
    authorize(authorization); info = ensure_mt5()
    return {"connected": True, "login": info.login, "server": info.server, "currency": info.currency,
            "balance": info.balance, "equity": info.equity, "trade_allowed": info.trade_allowed,
            "account_trade_mode": info.trade_mode, "live_allowed_on_bridge": ALLOW_LIVE}

@app.get("/bot/status")
def bot_status(authorization: str | None = Header(default=None)):
    authorize(authorization)
    info = ensure_mt5()
    with lock:
        return {"running": state["running"], "mode": state["mode"], "symbol": state["symbol"],
                "timeframe": "M1", "last_signal": state["last_signal"], "last_error": state["last_error"],
                "emergency_stop": state["emergency_stop"], "trades_today": state["trades_today"],
                "equity": info.equity, "balance": info.balance, "open_positions": len(open_positions(state["symbol"])),
                "risk_percent": state["risk_percent"], "max_open_trades": state["max_open_trades"],
                "daily_loss_limit_percent": state["daily_loss_limit_percent"], "last_order": state["last_order"]}

@app.post("/bot/start")
def bot_start(req: StartRequest, authorization: str | None = Header(default=None)):
    global worker_thread
    authorize(authorization)
    info = ensure_mt5()
    if req.mode == "live":
        if not req.live_confirmed:
            raise HTTPException(400, "Explicit live-trading confirmation required")
        if not ALLOW_LIVE:
            raise HTTPException(403, "Live trading disabled on bridge. Keep disabled until demo tests are complete.")
        if info.trade_mode == mt5.ACCOUNT_TRADE_MODE_DEMO:
            raise HTTPException(400, "Selected MT5 account is DEMO, not LIVE.")
    with lock:
        if state["running"]:
            raise HTTPException(409, "Bot is already running")
        state.update({"mode": req.mode, "symbol": req.symbol.strip(), "risk_percent": req.risk_percent,
                      "sl_atr_multiple": req.sl_atr_multiple, "tp_r_multiple": req.tp_r_multiple,
                      "max_open_trades": req.max_open_trades, "daily_loss_limit_percent": req.daily_loss_limit_percent,
                      "running": True, "emergency_stop": False, "last_error": "", "last_bar": 0,
                      "day_key": "", "last_signal": "Starting EMA/RSI M1 scanner..."})
        worker_thread = threading.Thread(target=worker, daemon=True)
        worker_thread.start()
    return {"started": True, "mode": req.mode, "symbol": req.symbol, "timeframe": "M1",
            "warning": "Live trading can lose money. Monitor the terminal and test on demo first."}

@app.post("/bot/stop")
def bot_stop(authorization: str | None = Header(default=None)):
    authorize(authorization)
    with lock:
        state["running"] = False
        state["last_signal"] = "Bot stopped by user"
    return {"stopped": True, "note": "Stops new entries; existing positions remain managed by their SL/TP."}

@app.post("/bot/emergency-stop")
def emergency_stop(authorization: str | None = Header(default=None)):
    authorize(authorization)
    with lock:
        state["running"] = False
        state["emergency_stop"] = True
        state["last_signal"] = "EMERGENCY STOP: new entries disabled. Existing positions are not automatically closed."
    return {"stopped": True, "emergency_stop": True,
            "note": "New entries disabled. Existing positions remain open with their broker-side SL/TP; close them manually if needed."}
