package com.smartxinon.signalscanner

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.max

data class Trade(val id: Long, val symbol: String, val direction: String, val volume: Double,
                 val status: String, val note: String = "")

class TradingViewModel : ViewModel() {
    var mode by mutableStateOf("DEMO")
    var bridgeUrl by mutableStateOf("https://YOUR-VPS-HOST:8443")
    var apiKey by mutableStateOf("")
    var symbol by mutableStateOf("XAUUSD")
    var volume by mutableStateOf("0.01")
    var stopLoss by mutableStateOf("")
    var takeProfit by mutableStateOf("")
    var connectionStatus by mutableStateOf("Not connected")
    var accountInfo by mutableStateOf("Connect to your MT5 bridge to load account info.")
    var busy by mutableStateOf(false)
    var liveArmed by mutableStateOf(false)
    var requireLiveConfirmation by mutableStateOf(false)
    var balance by mutableDoubleStateOf(1000.0); private set
    private val startBalance = 1000.0
    var stake by mutableDoubleStateOf(10.0)
    var payout by mutableDoubleStateOf(0.80)
    var autoDemo by mutableStateOf(true)
    var scannerRunning by mutableStateOf(false); private set
    var minScore by mutableIntStateOf(2)
    val openTrades = mutableStateListOf<Trade>()
    val history = mutableStateListOf<Trade>()
    val balancePoints = mutableStateListOf<Double>().apply { add(1000.0) }
    var lastSignal by mutableStateOf("Demo mode. No live signals are generated yet."); private set
    var wins by mutableIntStateOf(0); private set
    var losses by mutableIntStateOf(0); private set
    var message by mutableStateOf("Demo mode is selected by default.")
    var botStatus by mutableStateOf("MT5 auto bot stopped")
    var riskPercent by mutableStateOf("0.5")
    var slAtr by mutableStateOf("1.5")
    var tpR by mutableStateOf("2.0")
    var maxOpen by mutableStateOf("1")
    var dailyLimit by mutableStateOf("2.0")
    var liveConfirmation by mutableStateOf(false)

    fun connect() {
        if (bridgeUrl.contains("YOUR-VPS-HOST") || !bridgeUrl.startsWith("https://")) {
            message = "Enter your secure HTTPS MT5 bridge URL first."
            return
        }
        busy = true
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) { request("GET", "/account", null) }
            busy = false
            if (result.first) {
                connectionStatus = "Connected"
                accountInfo = result.second
                message = "MT5 bridge responded. Check account mode before trading."
            } else {
                connectionStatus = "Connection failed"
                message = result.second
            }
        }
    }

    fun sendMt5Order(direction: String) {
        if (mode != "LIVE") { message = "Switch to LIVE mode to request an MT5 order."; return }
        if (!liveArmed || !requireLiveConfirmation) {
            message = "For safety, enable Live trading and confirm live-order permission first."
            return
        }
        val vol = volume.toDoubleOrNull()
        val sl = stopLoss.toDoubleOrNull()
        val tp = takeProfit.toDoubleOrNull()
        if (vol == null || vol <= 0 || sl == null || tp == null || sl <= 0 || tp <= 0) {
            message = "Enter a valid volume, stop-loss price and take-profit price."
            return
        }
        busy = true
        viewModelScope.launch {
            val body = JSONObject().put("mode", "live").put("symbol", symbol.trim())
                .put("side", direction.lowercase()).put("volume", vol)
                .put("sl", sl).put("tp", tp).toString()
            val result = withContext(Dispatchers.IO) { request("POST", "/trade", body) }
            busy = false
            message = result.second
            if (result.first) {
                history.add(0, Trade(System.currentTimeMillis(), symbol, direction, vol, "REQUESTED", result.second))
            }
        }
    }

    fun startAutoBot() {
        if (mode == "LIVE" && !liveConfirmation) {
            message = "Confirm that you understand live orders risk real money."
            return
        }
        val risk = riskPercent.toDoubleOrNull()
        val sl = slAtr.toDoubleOrNull()
        val tp = tpR.toDoubleOrNull()
        val maxTrades = maxOpen.toIntOrNull()
        val daily = dailyLimit.toDoubleOrNull()
        if (risk == null || sl == null || tp == null || maxTrades == null || daily == null) {
            message = "Enter valid risk settings."; return
        }
        if (risk !in 0.1..1.0 || sl !in 0.5..5.0 || tp !in 1.0..5.0 || maxTrades !in 1..3 || daily !in 0.5..5.0) {
            message = "Settings outside safety limits. Risk 0.1–1%, SL ATR 0.5–5, TP 1–5R, max trades 1–3, daily loss 0.5–5%."; return
        }
        busy = true
        viewModelScope.launch {
            val body = JSONObject().put("mode", if (mode=="LIVE") "live" else "demo")
                .put("symbol", symbol.trim()).put("risk_percent", risk).put("sl_atr_multiple", sl)
                .put("tp_r_multiple", tp).put("max_open_trades", maxTrades)
                .put("daily_loss_limit_percent", daily).put("live_confirmed", liveConfirmation).toString()
            val result = withContext(Dispatchers.IO) { request("POST", "/bot/start", body) }
            busy = false; message = result.second
            if (result.first) botStatus = "MT5 auto bot running • $mode"
        }
    }

    fun stopAutoBot(emergency: Boolean = false) {
        busy = true
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) {
                request("POST", if (emergency) "/bot/emergency-stop" else "/bot/stop", "{}")
            }
            busy = false; message = result.second
            if (result.first) botStatus = if (emergency) "EMERGENCY STOP active" else "MT5 auto bot stopped"
        }
    }

    private fun request(method: String, path: String, body: String?): Pair<Boolean, String> {
        return try {
            val base = bridgeUrl.trimEnd('/')
            val conn = (URL(base + path).openConnection() as HttpURLConnection)
            conn.requestMethod = method
            conn.connectTimeout = 7000
            conn.readTimeout = 10000
            conn.setRequestProperty("Authorization", "Bearer ${apiKey.trim()}")
            conn.setRequestProperty("Content-Type", "application/json")
            if (body != null) {
                conn.doOutput = true
                conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: "HTTP $code"
            conn.disconnect()
            (code in 200..299) to text
        } catch (e: Exception) {
            false to "Could not reach bridge: ${e.message ?: "network error"}"
        }
    }

    fun startDemoScanner() {
        if (mode != "DEMO") { message = "Demo scanner is only available in DEMO mode."; return }
        scannerRunning = true
        lastSignal = "SIMULATED scanner running; this is not live market analysis."
        viewModelScope.launch {
            repeat(20) {
                if (!scannerRunning) return@launch
                kotlinx.coroutines.delay(15000)
                val score = (1..3).random()
                val side = if ((0..1).random() == 0) "CALL" else "PUT"
                lastSignal = "$side • simulated score $score/3 • 1m"
                if (autoDemo && score >= minScore) openDemoTrade(side)
                settleExpired()
            }
            scannerRunning = false
        }
    }
    fun stopDemoScanner() { scannerRunning = false; lastSignal = "Demo scanner stopped." }
    private fun openDemoTrade(side: String) {
        if (openTrades.size >= 5 || stake <= 0 || stake > balance) return
        balance -= stake
        openTrades.add(Trade(System.currentTimeMillis(), "DEMO", side, stake, "OPEN"))
        balancePoints.add(balance)
    }
    private fun settleExpired() {
        // Demo trades settle on the next scanner tick. Results are random, not predictive.
        openTrades.toList().forEach { t ->
            val won = (0..99).random() < 52
            val pnl = if (won) t.volume * payout else -t.volume
            if (won) { balance += t.volume + t.volume*payout; wins++ } else losses++
            history.add(0, t.copy(status=if(won) "WIN" else "LOSS", note="Simulated P/L ${"%.2f".format(pnl)}"))
            openTrades.remove(t); balancePoints.add(balance)
        }
    }
    fun resetDemo() {
        stopDemoScanner(); balance=startBalance; openTrades.clear(); history.clear()
        balancePoints.clear(); balancePoints.add(balance); wins=0; losses=0
        message="Demo account reset."
    }
    val winRate get() = if(wins+losses==0) 0.0 else wins.toDouble()/(wins+losses)*100
    val pnl get() = balance-startBalance
}

@Composable fun App(vm: TradingViewModel = viewModel()) {
    MaterialTheme(colorScheme=darkColorScheme(background=Color(0xFF090B10), surface=Color(0xFF11151D), primary=Color(0xFF62D6A7))) {
        Surface(Modifier.fillMaxSize(), color=MaterialTheme.colorScheme.background) {
            LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
                item { Text("SIGNAL SCANNER MT5", style=MaterialTheme.typography.titleLarge, fontWeight=FontWeight.Bold); Text("MT5 bridge • Demo and live modes", color=Color.Gray) }
                item { Card { Column(Modifier.padding(16.dp)) {
                    Text("Trading mode", fontWeight=FontWeight.Bold)
                    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected=vm.mode=="DEMO", onClick={vm.mode="DEMO"; vm.liveArmed=false}, label={Text("DEMO")})
                        FilterChip(selected=vm.mode=="LIVE", onClick={vm.mode="LIVE"; vm.liveArmed=false}, label={Text("LIVE")})
                    }
                    Text(if(vm.mode=="DEMO") "Demo simulation only. No broker orders." else "LIVE MODE: order requests can risk real money.", color=if(vm.mode=="LIVE") Color(0xFFFF6B6B) else Color.Gray)
                } } }
                item { Card { Column(Modifier.padding(16.dp), verticalArrangement=Arrangement.spacedBy(8.dp)) {
                    Text("MT5 bridge connection", fontWeight=FontWeight.Bold)
                    OutlinedTextField(vm.bridgeUrl, {vm.bridgeUrl=it}, label={Text("Bridge HTTPS URL")}, modifier=Modifier.fillMaxWidth(), singleLine=true)
                    OutlinedTextField(vm.apiKey, {vm.apiKey=it}, label={Text("Bridge API key")}, modifier=Modifier.fillMaxWidth(), singleLine=true)
                    Button(onClick=vm::connect, enabled=!vm.busy, modifier=Modifier.fillMaxWidth()) { Text(if(vm.busy) "Connecting…" else "Connect / check account") }
                    Text(vm.connectionStatus, color=Color.Gray); Text(vm.accountInfo, color=Color.Gray)
                } } }
                item { Card { Column(Modifier.padding(16.dp), verticalArrangement=Arrangement.spacedBy(8.dp)) {
                    Text("Automatic XAUUSD bot • M1", fontWeight=FontWeight.Bold)
                    Text("EMA 9/21 crossover + RSI 14 confirmation: BUY on bullish crossover with RSI ≥ 55; SELL on bearish crossover with RSI ≤ 45.", color=Color.Gray, style=MaterialTheme.typography.bodySmall)
                    Text(vm.botStatus, color=Color(0xFF62D6A7))
                    OutlinedTextField(vm.riskPercent,{vm.riskPercent=it},label={Text("Risk per trade (% equity, 0.1–1.0)")},modifier=Modifier.fillMaxWidth(),singleLine=true)
                    OutlinedTextField(vm.slAtr,{vm.slAtr=it},label={Text("Stop-loss ATR multiplier (0.5–5)")},modifier=Modifier.fillMaxWidth(),singleLine=true)
                    OutlinedTextField(vm.tpR,{vm.tpR=it},label={Text("Take-profit R multiple (1–5)")},modifier=Modifier.fillMaxWidth(),singleLine=true)
                    OutlinedTextField(vm.maxOpen,{vm.maxOpen=it},label={Text("Maximum open trades (1–3)")},modifier=Modifier.fillMaxWidth(),singleLine=true)
                    OutlinedTextField(vm.dailyLimit,{vm.dailyLimit=it},label={Text("Daily equity loss stop (%)")},modifier=Modifier.fillMaxWidth(),singleLine=true)
                    if(vm.mode=="LIVE") {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween) {
                            Text("I explicitly authorize automatic live orders")
                            Switch(checked=vm.liveConfirmation,onCheckedChange={vm.liveConfirmation=it})
                        }
                        Text("Live mode also requires ALLOW_LIVE_TRADING=true on the private bridge and a real MT5 account.", color=Color(0xFFFF6B6B), style=MaterialTheme.typography.bodySmall)
                    }
                    Button(onClick=vm::startAutoBot, enabled=!vm.busy, modifier=Modifier.fillMaxWidth()) { Text("Start automatic MT5 bot") }
                    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick={vm::stopAutoBot, modifier=Modifier.weight(1f)) { Text("Stop entries") }
                        Button(onClick={vm.stopAutoBot(true)}, modifier=Modifier.weight(1f), colors=ButtonDefaults.buttonColors(containerColor=Color(0xFFB3261E))) { Text("EMERGENCY STOP") }
                    }
                    Text("Emergency stop prevents new entries; it does not close existing positions. SL/TP are sent to MT5 with each trade.", color=Color.Gray, style=MaterialTheme.typography.bodySmall)
                    Text("Manual MT5 order ticket (optional)", fontWeight=FontWeight.Bold)
                    OutlinedTextField(vm.symbol,{vm.symbol=it},label={Text("MT5 symbol (e.g. XAUUSD)")},modifier=Modifier.fillMaxWidth(),singleLine=true)
                    OutlinedTextField(vm.volume,{vm.volume=it},label={Text("Volume in lots (e.g. 0.01)")},modifier=Modifier.fillMaxWidth(),singleLine=true)
                    OutlinedTextField(vm.stopLoss,{vm.stopLoss=it},label={Text("Stop-loss price (required)")},modifier=Modifier.fillMaxWidth(),singleLine=true)
                    OutlinedTextField(vm.takeProfit,{vm.takeProfit=it},label={Text("Take-profit price (required)")},modifier=Modifier.fillMaxWidth(),singleLine=true)
                    if(vm.mode=="LIVE") {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween) {
                            Text("I understand this can place a real order")
                            Switch(checked=vm.requireLiveConfirmation,onCheckedChange={vm.requireLiveConfirmation=it})
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween) {
                            Text("Arm live trading")
                            Switch(checked=vm.liveArmed,onCheckedChange={vm.liveArmed=it})
                        }
                    }
                    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                        Button(onClick={vm.sendMt5Order("BUY")}, enabled=!vm.busy && vm.mode=="LIVE", modifier=Modifier.weight(1f)) { Text("LIVE BUY") }
                        Button(onClick={vm.sendMt5Order("SELL")}, enabled=!vm.busy && vm.mode=="LIVE", modifier=Modifier.weight(1f)) { Text("LIVE SELL") }
                    }
                    Text("Live buttons are disabled in DEMO mode. A secure MT5 bridge must be running on a Windows PC/VPS with MT5 installed.", color=Color.Gray, style=MaterialTheme.typography.bodySmall)
                } } }
                item { Text(vm.message, color=Color(0xFF62D6A7)) }
                item { Card { Column(Modifier.padding(16.dp)) {
                    Text("Demo dashboard", fontWeight=FontWeight.Bold)
                    Text("Balance: $%.2f".format(vm.balance), style=MaterialTheme.typography.headlineSmall)
                    Text("P/L: %+.2f • Win rate: %.1f%%".format(vm.pnl,vm.winRate))
                    BalanceChart(vm.balancePoints)
                    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                        Button(onClick=vm::startDemoScanner, enabled=vm.mode=="DEMO" && !vm.scannerRunning) { Text("Start demo scanner") }
                        OutlinedButton(onClick=vm::stopDemoScanner) { Text("Stop") }
                        OutlinedButton(onClick=vm::resetDemo) { Text("Reset") }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween) {
                        Text("Automatic demo execution"); Switch(checked=vm.autoDemo,onCheckedChange={vm.autoDemo=it},enabled=vm.mode=="DEMO")
                    }
                    Text(vm.lastSignal,color=Color.Gray)
                    Text("Stake: $%.2f".format(vm.stake))
                    Slider(value=vm.stake.toFloat(),onValueChange={vm.stake=it.toDouble()},valueRange=1f..100f)
                    Text("Payout: %.0f%%".format(vm.payout*100))
                    Slider(value=vm.payout.toFloat(),onValueChange={vm.payout=it.toDouble()},valueRange=.5f..1f)
                    Text("Signal threshold: ${vm.minScore}/3")
                    Slider(value=vm.minScore.toFloat(),onValueChange={vm.minScore=it.toInt().coerceIn(1,3)},valueRange=1f..3f,steps=1)
                } } }
                item { Text("Open demo trades",fontWeight=FontWeight.Bold) }
                if(vm.openTrades.isEmpty()) item { Text("No open demo trades",color=Color.Gray) }
                items(vm.openTrades,key={it.id}) { TradeRow(it) }
                item { Text("Trade history / MT5 order requests",fontWeight=FontWeight.Bold) }
                if(vm.history.isEmpty()) item { Text("No history yet",color=Color.Gray) }
                items(vm.history.take(30),key={it.id}) { TradeRow(it) }
                item { Text("Live orders use your MT5 account and can lose money. Test on a broker demo account first. The automatic EMA/RSI strategy runs on the Windows bridge.",color=Color.Gray,style=MaterialTheme.typography.bodySmall) }
            }
        }
    }
}
@Composable fun TradeRow(t:Trade) {
    Card { Row(Modifier.fillMaxWidth().padding(12.dp),horizontalArrangement=Arrangement.SpaceBetween) {
        Column { Text("${t.symbol} • ${t.direction}",fontWeight=FontWeight.Bold); Text("Volume ${t.volume}",color=Color.Gray); if(t.note.isNotBlank()) Text(t.note,color=Color.Gray) }
        Text(t.status,color=when(t.status){"WIN"->Color(0xFF62D6A7);"LOSS"->Color(0xFFFF6B6B);else->Color.Yellow})
    } }
}
@Composable fun BalanceChart(points:List<Double>) {
    Canvas(Modifier.fillMaxWidth().height(110.dp)) {
        if(points.size<2) return@Canvas
        val low=points.minOrNull()?:0.0; val high=points.maxOrNull()?:1.0; val span=max(high-low,0.01)
        val path=Path()
        points.forEachIndexed { i,v ->
            val x=i.toFloat()/(points.size-1)*size.width
            val y=size.height-(((v-low)/span).toFloat()*size.height)
            if(i==0) path.moveTo(x,y) else path.lineTo(x,y)
        }
        drawPath(path,color=Color(0xFF62D6A7),style=androidx.compose.ui.graphics.drawscope.Stroke(width=4f))
    }
}
class MainActivity:ComponentActivity() {
    override fun onCreate(savedInstanceState:Bundle?) { super.onCreate(savedInstanceState); setContent { App() } }
}
