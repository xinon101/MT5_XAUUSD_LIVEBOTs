# SignalScanner MT5 — LIVE-ONLY XAUUSD M1

This build removes the demo mode and simulated demo scanner from the Android app and bridge. It is designed for automatic XAUUSD trading on MT5 using EMA(9)/EMA(21) crossovers confirmed by RSI(14), evaluated on closed M1 candles.

## Live safeguards (still required)
- Live execution is **disabled by default** on the bridge. Do not enable it until you understand and accept the risk.
- The app requires explicit live-order confirmation.
- The bridge requires `ALLOW_LIVE_TRADING=true`, an API key, and a real MT5 account.
- Default risk is 0.5% equity per trade, ATR-based stop-loss (1.5x ATR), take-profit at 2R, max one open position, 2% daily equity-loss stop, and 0.10-lot hard cap.
- Emergency stop prevents new entries but does not close existing positions; existing broker-side SL/TP remain active.
- Run the bridge on a Windows PC/VPS with MT5 installed and logged into the correct account. Protect it behind a private VPN and HTTPS reverse proxy; do not expose it directly to the internet.

**Important:** A live-only build is not evidence of profitability. Backtest the strategy and verify the bridge, symbol name, lot sizing, SL/TP and daily-loss handling carefully. Live trading can lose money. No accuracy or profit is guaranteed.
